#!/bin/bash
set -euo pipefail

# 使用 macOS 自带 Bash 3.2、unzip 和文件工具，不依赖额外运行环境。
CURRENT_DIR="$(cd "$(dirname "$0")" && pwd)"
LOG_FILE="$CURRENT_DIR/install.log"
ASAR_FILE="$CURRENT_DIR/app.asar"
ASAR_BAK="$CURRENT_DIR/app.asar.bak"
ZIP_FILE="$CURRENT_DIR/app.zip"
APP_DIR="$CURRENT_DIR/app"
STAGE="$CURRENT_DIR/.xiaochao-install"
CANDIDATE="$STAGE/unpacked/app"
OLD_APP="$STAGE/old-app"
OLD_ASAR_BAK="$STAGE/old-app.asar.bak"
stage_created=0
app_backed_up=0
app_installed=0
asar_backup_saved=0
asar_renamed=0
committed=0

log() {
  local message="[$(date '+%Y-%m-%d %H:%M:%S')] $1"
  printf '%s\n' "$message"
  if ! printf '%s\n' "$message" >> "$LOG_FILE"; then
    printf '%s\n' '警告：无法写入 install.log。' >&2
  fi
}

# 不让日志写入失败掩盖文件操作的实际结果。
run() {
  local result=0
  if "$@" > "$STAGE/command.log" 2>&1; then
    result=0
  else
    result=$?
  fi
  if [ -s "$STAGE/command.log" ]; then
    log "$(cat "$STAGE/command.log")"
  fi
  return "$result"
}

# mv 在目标目录已存在时会嵌套移动；明确拒绝这种情况，避免误报恢复成功。
move_path() {
  if [ -e "$2" ] || [ -L "$2" ]; then
    log "错误：目标位置已存在，未移动文件：$2"
    return 1
  fi
  run mv "$1" "$2"
}

restore_previous() {
  if [ "$asar_renamed" -eq 1 ]; then
    move_path "$ASAR_BAK" "$ASAR_FILE" || return 1
  fi
  if [ "$asar_backup_saved" -eq 1 ]; then
    move_path "$OLD_ASAR_BAK" "$ASAR_BAK" || return 1
  fi
  if [ "$app_installed" -eq 1 ]; then
    move_path "$APP_DIR" "$CANDIDATE" || return 1
  fi
  if [ "$app_backed_up" -eq 1 ]; then
    move_path "$OLD_APP" "$APP_DIR" || return 1
  fi
}

finish() {
  local result=$?
  trap - EXIT INT TERM HUP
  if [ "$stage_created" -eq 1 ]; then
    if [ "$committed" -eq 0 ]; then
      log '安装未完成，正在保留或恢复原有安装。'
      if ! restore_previous; then
        log "自动恢复失败，请勿删除备份目录：$STAGE"
        log 'old-app 对应原 app，old-app.asar.bak 对应原 app.asar.bak，请根据 install.log 手动恢复。'
        exit 1
      fi
      log '原有安装已保留或恢复。'
    fi
    # 只有安装成功或恢复成功后，才清理本次创建的临时目录。
    if ! rm -rf "$STAGE"; then
      log "临时目录未能清理，请检查后手动移走：$STAGE"
    fi
  fi
  exit "$result"
}
trap finish EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
trap 'exit 129' HUP

log '开始安装'
if [ ! -w "$CURRENT_DIR" ]; then
  log '错误：没有写入权限，请在本目录执行 sudo bash install.sh。'
  exit 1
fi
if ! command -v unzip >/dev/null 2>&1; then
  log '错误：未找到 unzip，请按照安装说明进行手动安装。'
  exit 1
fi
if [ ! -f "$ZIP_FILE" ]; then
  log '错误：当前目录缺少 app.zip，请将 app.zip 和 install.sh 放在官方微端的 Contents/Resources 目录中。'
  exit 1
fi
if [ ! -f "$ASAR_FILE" ] && [ ! -f "$ASAR_BAK" ] && [ ! -d "$APP_DIR" ]; then
  log '错误：未找到原有微端文件，请确认当前目录是官方微端的 Contents/Resources 目录。'
  exit 1
fi
if pgrep -x SGSOL >/dev/null 2>&1; then
  log '错误：三国杀微端仍在运行，请先完全退出。'
  exit 1
fi
if [ -e "$STAGE" ] || [ -L "$STAGE" ]; then
  log "发现上次安装留下的目录，请先检查备份并恢复，再移走该目录后重试：$STAGE"
  exit 1
fi
# 不使用 mkdir -p，防止并发安装覆盖另一实例的备份。
mkdir "$STAGE"
stage_created=1

log '正在解压并检查新安装包，现有安装保持不变。'
if ! run unzip -q "$ZIP_FILE" -d "$STAGE/unpacked"; then
  log '错误：解压失败，请查看上方的具体报错和 install.log。'
  exit 1
fi
for relative in package.json main.js xiaochao.js index_wd.html script/electron_renderer.js script/electron_frame.js; do
  if [ ! -f "$CANDIDATE/$relative" ]; then
    log "错误：安装包不完整，缺少 app/$relative。"
    exit 1
  fi
done
if [ -f "$APP_DIR/config.json" ]; then
  run cp "$APP_DIR/config.json" "$CANDIDATE/config.json"
fi
if pgrep -x SGSOL >/dev/null 2>&1; then
  log '错误：三国杀微端仍在运行，请先完全退出。'
  exit 1
fi

log '安装包检查通过，正在替换；旧文件将保留到安装成功。'
if [ -e "$APP_DIR" ] || [ -L "$APP_DIR" ]; then
  move_path "$APP_DIR" "$OLD_APP"
  app_backed_up=1
fi
move_path "$CANDIDATE" "$APP_DIR"
app_installed=1
if [ -e "$ASAR_FILE" ] || [ -L "$ASAR_FILE" ]; then
  if [ -e "$ASAR_BAK" ] || [ -L "$ASAR_BAK" ]; then
    move_path "$ASAR_BAK" "$OLD_ASAR_BAK"
    asar_backup_saved=1
  fi
  move_path "$ASAR_FILE" "$ASAR_BAK"
  asar_renamed=1
fi
committed=1
log '小抄微端插件安装成功，请重新打开三国杀微端。'
