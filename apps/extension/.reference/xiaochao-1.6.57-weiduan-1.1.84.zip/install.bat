@echo off
chcp 65001 >nul
setlocal DisableDelayedExpansion
set "XC_INSTALL_SCRIPT=%~f0"
set "XC_INSTALL_ROOT=%~dp0"
set "INSTALL_POWERSHELL=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%INSTALL_POWERSHELL%" (
    echo 错误：无法使用 Windows PowerShell。
    echo 请按照安装包内的安装说明进行手动安装。
    echo 按任意键继续。
    pause >nul
    exit /b 1
)
REM Read the embedded script as UTF-8; paths are passed through environment variables.
"%INSTALL_POWERSHELL%" -NoProfile -NonInteractive -ExecutionPolicy Bypass -Command "$ErrorActionPreference = 'Stop'; try { $source = [IO.File]::ReadAllText($env:XC_INSTALL_SCRIPT, [Text.Encoding]::UTF8); $marker = '# POWERSHELL_' + 'INSTALL_START'; $body = $source.Substring($source.IndexOf($marker) + $marker.Length); & ([ScriptBlock]::Create($body)) } catch { Write-Host ($_ | Out-String); exit 1 }"
set "INSTALL_RESULT=%errorlevel%"
echo.
echo 按任意键继续。
pause >nul
exit /b %INSTALL_RESULT%

# POWERSHELL_INSTALL_START
function Write-InstallMessage {
    param([string]$Message)
    Write-Host $Message
    try {
        Add-Content -LiteralPath (Join-Path $env:XC_INSTALL_ROOT 'install.log') -Value ('[{0}] {1}' -f (Get-Date), $Message) -Encoding UTF8 -ErrorAction Stop
    } catch {
        Write-Warning ('无法写入 install.log：' + $_.Exception.Message)
    }
}

function Install-MicroClient {
    param([string]$Root)
    $ErrorActionPreference = 'Stop'
    $archive = Join-Path $Root 'app.zip'
    $app = Join-Path $Root 'app'
    $asar = Join-Path $Root 'app.asar'
    $asarBackup = Join-Path $Root 'app.asar.bak'
    $stage = Join-Path $Root '.xiaochao-install'
    $unpacked = Join-Path $stage 'unpacked'
    $candidate = Join-Path $unpacked 'app'
    $oldApp = Join-Path $stage 'old-app'
    $oldAsarBackup = Join-Path $stage 'old-app.asar.bak'

    if (-not (Test-Path -LiteralPath $archive -PathType Leaf)) {
        throw '当前目录缺少 app.zip，请将 app.zip 和 install.bat 放在官方微端的 resources 目录中。'
    }
    if (-not ((Test-Path -LiteralPath $asar -PathType Leaf) -or (Test-Path -LiteralPath $asarBackup -PathType Leaf) -or (Test-Path -LiteralPath $app -PathType Container))) {
        throw '未找到原有微端文件，请确认当前目录是官方微端的 resources 目录。'
    }
    if (Test-Path -LiteralPath $stage) {
        throw ('发现上次安装留下的目录，请先检查其中的备份并恢复，再移走该目录后重试：' + $stage)
    }
    # New-Item refuses an existing directory, including one created by another installer.
    New-Item -ItemType Directory -Path $stage | Out-Null
    $appBackedUp = $false
    $appInstalled = $false
    $asarBackupSaved = $false
    $asarRenamed = $false
    try {
        Write-InstallMessage '正在解压并检查新安装包，现有安装保持不变。'
        Expand-Archive -LiteralPath $archive -DestinationPath $unpacked -ErrorAction Stop
        foreach ($relative in @('package.json', 'main.js', 'xiaochao.js', 'index_wd.html', 'script/electron_renderer.js', 'script/electron_frame.js')) {
            if (-not (Test-Path -LiteralPath (Join-Path $candidate $relative) -PathType Leaf)) {
                throw ('安装包不完整，缺少 app/' + $relative)
            }
        }
        $package = Get-Content -LiteralPath (Join-Path $candidate 'package.json') -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($package.main -ne 'main.js') { throw '安装包的启动入口不正确。' }
        # Preserve legacy configuration when reinstalling an older micro-client.
        $legacyConfig = Join-Path $app 'config.json'
        if (Test-Path -LiteralPath $legacyConfig -PathType Leaf) {
            Copy-Item -LiteralPath $legacyConfig -Destination (Join-Path $candidate 'config.json')
        }
        if (Get-Process -Name SGSOL -ErrorAction SilentlyContinue) { throw '三国杀微端仍在运行，请先完全退出。' }

        Write-InstallMessage '安装包检查通过，正在替换；旧文件将保留到安装成功。'
        if (Test-Path -LiteralPath $app) {
            [IO.Directory]::Move($app, $oldApp)
            $appBackedUp = $true
        }
        [IO.Directory]::Move($candidate, $app)
        $appInstalled = $true
        if (Test-Path -LiteralPath $asar) {
            if (Test-Path -LiteralPath $asarBackup) {
                [IO.File]::Move($asarBackup, $oldAsarBackup)
                $asarBackupSaved = $true
            }
            [IO.File]::Move($asar, $asarBackup)
            $asarRenamed = $true
        }
    } catch {
        $installError = $_
        Write-InstallMessage ('安装失败：' + ($installError | Out-String))
        try {
            if ($asarRenamed) { [IO.File]::Move($asarBackup, $asar) }
            if ($asarBackupSaved) { [IO.File]::Move($oldAsarBackup, $asarBackup) }
            # Move the new app out of the way rather than deleting files during rollback.
            if ($appInstalled) { [IO.Directory]::Move($app, $candidate) }
            if ($appBackedUp) { [IO.Directory]::Move($oldApp, $app) }
        } catch {
            Write-InstallMessage ('自动恢复失败：' + ($_ | Out-String))
            throw ('请勿删除备份目录：' + $stage + '。old-app 是原 app，old-app.asar.bak 是原 app.asar.bak。请根据 install.log 手动恢复。')
        }
        Write-InstallMessage '原有安装已保留或恢复。'
        try { Remove-Item -LiteralPath $stage -Recurse -Force } catch {
            Write-InstallMessage ('临时目录未能清理，请检查后手动移走：' + $stage)
        }
        throw $installError
    }
    # Cleanup failure must not roll back a completed installation or delete the current app.
    try { Remove-Item -LiteralPath $stage -Recurse -Force } catch {
        Write-InstallMessage ('安装已完成，但旧备份未能清理，请检查后手动移走：' + $stage)
    }
    Write-InstallMessage '小抄微端插件安装成功，请重新打开三国杀微端。'
}

# POWERSHELL_INSTALL_RUN
try {
    Write-InstallMessage ('开始安装，Windows PowerShell 版本：' + $PSVersionTable.PSVersion)
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw '请右键点击 install.bat，选择以管理员身份运行。'
    }
    Get-Command Expand-Archive -ErrorAction Stop | Out-Null
    if (Get-Process -Name SGSOL -ErrorAction SilentlyContinue) { throw '三国杀微端仍在运行，请先完全退出。' }
    Install-MicroClient -Root $env:XC_INSTALL_ROOT
    exit 0
} catch {
    Write-InstallMessage ('错误：' + ($_ | Out-String))
    Write-Host '请查看上方的具体报错和同目录下的 install.log。'
    exit 1
}
